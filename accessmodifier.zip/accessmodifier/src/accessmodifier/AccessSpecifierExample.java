package accessmodifier;

//Define a class with various access specifiers
class MyClass {
 // Public variable accessible from anywhere
 public int publicVar = 10;

 // Protected variable accessible within the same package and subclasses
 protected int protectedVar = 20;

 // Default (package-private) variable accessible within the same package
 int defaultVar = 30;

 // Private variable accessible only within the same class
 private int privateVar = 40;

 // Public method accessible from anywhere
 public void publicMethod() {
     System.out.println("Public Method");
 }

 // Protected method accessible within the same package and subclasses
 protected void protectedMethod() {
     System.out.println("Protected Method");
 }

 // Default (package-private) method accessible within the same package
 void defaultMethod() {
     System.out.println("Default Method");
 }

 // Private method accessible only within the same class
 private void privateMethod() {
     System.out.println("Private Method");
 }
}

public class AccessSpecifierExample {
 public static void main(String[] args) {
     // Create an instance of MyClass
     MyClass myObject = new MyClass();

     // Access public members
     System.out.println("Public Variable: " + myObject.publicVar);
     myObject.publicMethod();

     // Access protected members
     System.out.println("Protected Variable: " + myObject.protectedVar);
     myObject.protectedMethod();

     // Access default members
     System.out.println("Default Variable: " + myObject.defaultVar);
     myObject.defaultMethod();

     // Private members are not accessible from outside the class
     // Uncommenting the line below will result in a compilation error
     // System.out.println("Private Variable: " + myObject.privateVar);
     // myObject.privateMethod();
 }
}
