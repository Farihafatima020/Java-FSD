package taxcalculator;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

interface Taxable {
    double calculateTax();
}

class Property implements Taxable {
    private double builtUpArea;
    private double ageFactor;
    private double baseValue;
    private boolean isInCity;

    public Property(double builtUpArea, double ageFactor, double baseValue, boolean isInCity) {
        this.builtUpArea = builtUpArea;
        this.ageFactor = ageFactor;
        this.baseValue = baseValue;
        this.isInCity = isInCity;
    }

    @Override
    public double calculateTax() {
        if (isInCity) {
            return (builtUpArea * ageFactor * baseValue) + (0.5 * builtUpArea);
        } else {
            return builtUpArea * ageFactor * baseValue;
        }
    }

    public double getBuiltUpArea() {
        return builtUpArea;
    }

    public double getBaseValue() {
        return baseValue;
    }

    public boolean isInCity() {
        return isInCity;
    }
}

class Vehicle implements Taxable {
    private String registrationNumber;
    private String brand;
    private double purchaseCost;
    private double velocity;
    private int capacity;
    private int vehicleType;

    public Vehicle(String registrationNumber, String brand, double purchaseCost, double velocity, int capacity, int vehicleType) {
        this.registrationNumber = registrationNumber;
        this.brand = brand;
        this.purchaseCost = purchaseCost;
        this.velocity = velocity;
        this.capacity = capacity;
        this.vehicleType = vehicleType;
    }

    @Override
    public double calculateTax() {
        switch (vehicleType) {
            case 1:
                return velocity + capacity + 0.1 * purchaseCost;
            case 2:
                return velocity + capacity + 0.11 * purchaseCost;
            case 3:
                return velocity + capacity + 0.12 * purchaseCost;
            default:
                return 0.0;
        }
    }

    public double getVelocity() {
        return velocity;
    }

    public double getPurchaseCost() {
        return purchaseCost;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getVehicleType() {
        return vehicleType;
    }
}

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static ArrayList<Property> properties = new ArrayList<>();
    private static ArrayList<Vehicle> vehicles = new ArrayList<>();

    public static void main(String[] args) {
        int choice;
        do {
            displayMainMenu();
            choice = getUserChoice();

            switch (choice) {
                case 1:
                    addProperty();
                    break;
                case 2:
                    addVehicle();
                    break;
                case 3:
                    displayTaxSummary();
                    break;
                case 4:
                    System.out.println("Closing the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        } while (choice != 4);
    }

    private static void displayMainMenu() {
        System.out.println("\nMain Menu:");
        System.out.println("+--------------------------+");
        System.out.println("| Option | Description      |");
        System.out.println("+--------------------------+");
        System.out.println("|   1    | Add Property     |");
        System.out.println("|   2    | Add Vehicle      |");
        System.out.println("|   3    | Display Summary  |");
        System.out.println("|   4    | Close App        |");
        System.out.println("+--------------------------+");
    }

    private static int getUserChoice() {
        int choice = -1;
        do {
            try {
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // Clear the buffer
            }
        } while (choice < 1 || choice > 4);
        return choice;
    }

    private static void addProperty() {
        System.out.println("\nAdding Property:");

        double builtUpArea;
        double ageFactor;
        double baseValue;
        boolean isInCity;

        do {
            System.out.print("Enter built-up area: ");
            builtUpArea = getPositiveDoubleInput();
        } while (builtUpArea <= 0);

        do {
            System.out.print("Enter base value of the land: ");
            baseValue = getPositiveDoubleInput();
        } while (baseValue <= 0);

        char locationChoice;
        do {
            System.out.print("Is the property located in the main city? (Y/N): ");
            locationChoice = Character.toUpperCase(scanner.next().charAt(0));
        } while (locationChoice != 'Y' && locationChoice != 'N');

        isInCity = (locationChoice == 'Y');

        do {
            System.out.print("Enter the age of construction: ");
            ageFactor = getPositiveDoubleInput();
        } while (ageFactor <= 0);

        Property property = new Property(builtUpArea, ageFactor, baseValue, isInCity);
        double propertyTax = property.calculateTax();

        properties.add(property);

        System.out.println("Property added successfully. Calculated Property Tax: " + String.format("%.2f", propertyTax));
    }

    private static void addVehicle() {
        System.out.println("\nAdding Vehicle:");

        String registrationNumber;
        String brand;
        double purchaseCost;
        double velocity;
        int capacity;
        int vehicleType;

        do {
            System.out.print("Enter registration number (4 digits): ");
            registrationNumber = getValidRegistrationNumber();
        } while (registrationNumber.isEmpty());

        System.out.print("Enter brand of the vehicle: ");
        brand = scanner.next();

        do {
            System.out.print("Enter purchase cost: ");
            purchaseCost = getPositiveDoubleInput();
        } while (purchaseCost < 50000 || purchaseCost > 1000000);

        do {
            System.out.print("Enter maximum velocity (between 120 and 300 kmph): ");
            velocity = getPositiveDoubleInput();
        } while (velocity < 120 || velocity > 300);

        do {
            System.out.print("Enter capacity (number of seats, between 2 and 50): ");
            capacity = getPositiveIntInput();
        } while (capacity < 2 || capacity > 50);

        do {
            System.out.println("Choose type of vehicle:");
            System.out.println("1. Petrol-driven");
            System.out.println("2. Diesel-driven");
            System.out.println("3. CNG/LPG-driven");
            System.out.print("Enter choice: ");
            vehicleType = getPositiveIntInput();
        } while (vehicleType < 1 || vehicleType > 3);

        Vehicle vehicle = new Vehicle(registrationNumber, brand, purchaseCost, velocity, capacity, vehicleType);
        double vehicleTax = vehicle.calculateTax();

        vehicles.add(vehicle);

        System.out.println("Vehicle added successfully. Calculated Vehicle Tax: " + String.format("%.2f", vehicleTax));
    }

    private static void displayTaxSummary() {
        System.out.println("\nTax Summary:");

        if (properties.isEmpty() && vehicles.isEmpty()) {
            System.out.println("+-----------------------------------+");
            System.out.println("| No Data Present at This Moment.   |");
            System.out.println("+-----------------------------------+");
        } else {
            double totalPropertyTax = 0;
            System.out.println("\nProperties:");
            System.out.println("+------------------+--------------+------------------------+----------------------+");
            System.out.println("| Property Tax     | Built-up Area | Base Value of the Land | Property Location    |");
            System.out.println("+------------------+--------------+------------------------+----------------------+");
            for (Property property : properties) {
                double propertyTax = property.calculateTax();
                totalPropertyTax += propertyTax;
                System.out.printf("| %-16.2f | %-12.2f | %-22.2f | %-20s |\n",
                        propertyTax, property.getBuiltUpArea(), property.getBaseValue(), (property.isInCity() ? "In City" : "Not In City"));
            }
            System.out.println("+------------------+--------------+------------------------+----------------------+");
            System.out.println("| Total Properties | Total Tax     |                        |                      |");
            System.out.printf("| %-16d | %-12.2f |                        |                      |\n", properties.size(), totalPropertyTax);
            System.out.println("+------------------+--------------+------------------------+----------------------+");

            double totalVehicleTax = 0;
            System.out.println("\nVehicles:");
            System.out.println("+-----------------+--------------+-------------------+----------------------+---------------------+");
            System.out.println("| Vehicle Tax     | Max Velocity | Purchase Cost     | Capacity (No. of Seats)| Vehicle Type         |");
            System.out.println("+-----------------+--------------+-------------------+----------------------+---------------------+");
            for (Vehicle vehicle : vehicles) {
                double vehicleTax = vehicle.calculateTax();
                totalVehicleTax += vehicleTax;
                System.out.printf("| %-15.2f | %-12.2f | %-17.2f | %-20d | %-20s |\n",
                        vehicleTax, vehicle.getVelocity(), vehicle.getPurchaseCost(), vehicle.getCapacity(), vehicle.getVehicleType());
            }
            System.out.println("+-----------------+--------------+-------------------+----------------------+---------------------+");
            System.out.println("| Total Vehicles  | Total Tax     |                   |                      |                     |");
            System.out.printf("| %-15d | %-12.2f |                   |                      |                     |\n", vehicles.size(), totalVehicleTax);
            System.out.println("+-----------------+--------------+-------------------+----------------------+---------------------+");

            double totalTaxPayable = totalPropertyTax + totalVehicleTax;
            System.out.println("\nTotal Tax Payable:");
            System.out.println("+--------------------------+");
            System.out.printf("| %-24.2f |\n", totalTaxPayable);
            System.out.println("+--------------------------+");
        }

        System.out.println("\nPress Enter to go back to the main menu.");
        scanner.nextLine(); // Clear the buffer
        scanner.nextLine(); // Wait for Enter key
    }

    private static double getPositiveDoubleInput() {
        double value = -1;
        do {
            try {
                value = scanner.nextDouble();
                if (value <= 0) {
                    System.out.println("Invalid input. Please enter a positive number.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // Clear the buffer
            }
        } while (value <= 0);
        return value;
    }

    private static int getPositiveIntInput() {
        int value = -1;
        do {
            try {
                value = scanner.nextInt();
                if (value <= 0) {
                    System.out.println("Invalid input. Please enter a positive integer.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter an integer.");
                scanner.nextLine(); // Clear the buffer
            }
        } while (value <= 0);
        return value;
    }

    private static String getValidRegistrationNumber() {
        String registrationNumber = "";
        do {
            try {
                registrationNumber = scanner.next();
                int regNumber = Integer.parseInt(registrationNumber);
                if (regNumber < 0 || regNumber > 9999) {
                    System.out.println("Invalid registration number. Please enter a 4-digit number.");
                    registrationNumber = "";
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid registration number.");
                registrationNumber = "";
            }
        } while (registrationNumber.isEmpty());
        return registrationNumber;
    }
}
