/**
 * 
 */
/**
 * 
 */
module diamond {
}