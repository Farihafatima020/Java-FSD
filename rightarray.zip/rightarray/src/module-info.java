/**
 * 
 */
/**
 * 
 */
module rightarray {
}