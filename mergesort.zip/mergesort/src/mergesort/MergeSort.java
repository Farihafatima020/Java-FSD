package mergesort;
public class MergeSort {
    public static void main(String[] args) {
        int[] array = {12, 11, 13, 5, 6, 7};

        System.out.println("Original array:");
        printArray(array);

        mergeSort(array);

        System.out.println("\nSorted array:");
        printArray(array);
    }

    // Merge Sort function
    public static void mergeSort(int[] array) {
        int length = array.length;

        if (length > 1) {
            // Find the middle of the array
            int mid = length / 2;

            // Create left and right subarrays
            int[] leftArray = new int[mid];
            int[] rightArray = new int[length - mid];

            // Fill left subarray
            System.arraycopy(array, 0, leftArray, 0, mid);

            // Fill right subarray
            System.arraycopy(array, mid, rightArray, 0, length - mid);

            // Recursive calls to sort the two halves
            mergeSort(leftArray);
            mergeSort(rightArray);

            // Merge the sorted halves
            merge(array, leftArray, rightArray);
        }
    }

    // Merge function to merge two subarrays
    public static void merge(int[] array, int[] leftArray, int[] rightArray) {
        int leftLength = leftArray.length;
        int rightLength = rightArray.length;

        int i = 0, j = 0, k = 0;

        // Merge the left and right arrays
        while (i < leftLength && j < rightLength) {
            if (leftArray[i] <= rightArray[j]) {
                array[k++] = leftArray[i++];
            } else {
                array[k++] = rightArray[j++];
            }
        }

        // Copy remaining elements of leftArray, if any
        while (i < leftLength) {
            array[k++] = leftArray[i++];
        }

        // Copy remaining elements of rightArray, if any
        while (j < rightLength) {
            array[k++] = rightArray[j++];
        }
    }

    // Helper function to print an array
    public static void printArray(int[] array) {
        for (int value : array) {
            System.out.print(value + " ");
        }
        System.out.println();
    }
}