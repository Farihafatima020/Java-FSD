/**
 * 
 */
/**
 * 
 */
module typecasting {
}