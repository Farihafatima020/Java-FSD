/**
 * 
 */
/**
 * 
 */
module doublelink {
}