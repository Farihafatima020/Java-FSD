package exponentialsearch;

public class ExponentialSearch {

    // Exponential Search function
    static int exponentialSearch(int arr[], int n, int x) {
        // If the element is present at the first position
        if (arr[0] == x)
            return 0;

        // Find range for binary search by repeatedly doubling the index
        int i = 1;
        while (i < n && arr[i] <= x)
            i *= 2;

        // Perform binary search in the found range
        return binarySearch(arr, i / 2, Math.min(i, n), x);
    }

    // Binary Search function
    static int binarySearch(int arr[], int start, int end, int x) {
        if (end >= start) {
            int mid = start + (end - start) / 2;

            // If the element is present at the middle
            if (arr[mid] == x)
                return mid;

            // If the element is smaller than the middle, search in the left subarray
            if (arr[mid] > x)
                return binarySearch(arr, start, mid - 1, x);

            // If the element is larger than the middle, search in the right subarray
            return binarySearch(arr, mid + 1, end, x);
        }

        // If the element is not present in the array
        return -1;
    }

    // Main method for testing
    public static void main(String args[]) {
        int arr[] = {2, 3, 4, 10, 40};
        int n = arr.length;
        int x = 10;

        int result = exponentialSearch(arr, n, x);

        if (result == -1)
            System.out.println("Element not present in the array");
        else
            System.out.println("Element found at index " + result);
    }
}