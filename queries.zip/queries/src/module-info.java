/**
 * 
 */
/**
 * 
 */
module queries {
}